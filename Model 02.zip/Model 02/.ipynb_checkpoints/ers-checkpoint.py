# -*- coding: utf-8 -*-

import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

import pandas as pd
import nltk
from flask import Flask, request, render_template

# Load the pre-cleaned dataset
df = pd.read_csv("C:/Users/USER/Desktop/IRWA Project/Model 02/cleaned_dataset.csv")
df = df[['name', 'brand', 'categories', 'source_urls','search']]

# NLTK setup (assumed stopwords and tokenizer are pre-configured)
from nltk.corpus import stopwords
from nltk.stem import SnowballStemmer
nltk.download('punkt')
nltk.download('stopwords')
stmer = SnowballStemmer('english')

# Tokenization and stemming function (optimized for pre-cleaned text)
def tokenization(txt):
    tokens = nltk.word_tokenize(txt)
    stemming = [stmer.stem(w) for w in tokens if w not in stopwords.words('english')]
    return " ".join(stemming)

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Cosine similarity function (update to remove warning)
def cosine_sim(txt1, txt2):
    obj_tfidf = TfidfVectorizer(tokenizer=tokenization, token_pattern=None)  # Set token_pattern to None
    matrix = obj_tfidf.fit_transform([txt1, txt2])
    similarity = cosine_similarity(matrix)[0][1]
    return similarity


# Recommendation function
def recommendation(query):
    tokenized_query = tokenization(query)
    df['similarity'] = df['search'].apply(lambda x: cosine_sim(tokenized_query, x))
    final_df = df.sort_values(by=['similarity'], ascending=False).head(10)[['name', 'brand',]]
    return final_df

# Creating Flask app
app = Flask(__name__)

@app.route('/')
def index():
    names = df['name'].to_list()
    output = None
    return render_template('index.html', name=names, output=output)

@app.route("/recom", methods=['POST'])
def recommend():
    query = request.form['recommend']
    final_df = recommendation(query)

    # Handle case where no recommendations are found
    if final_df.empty:
        final_df = pd.DataFrame(columns=['name', 'brand'])  # Create empty DataFrame for consistency

    names = df['name'].to_list()  # Get names for the dropdown
    return render_template('index.html', output=final_df, name=names)
