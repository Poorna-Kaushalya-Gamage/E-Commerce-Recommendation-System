import os

from surprise.prediction_algorithms import matrix_factorization
from tensorflow.python.ops.linalg.linalg_impl import svd

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

import pandas as pd
import numpy as np
from flask import Flask, request, render_template, redirect, url_for, flash, session
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import mysql.connector
from sklearn.decomposition import TruncatedSVD

# MySQL Database Connection
def get_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='root',
        database='recommendation'
    )

# Load the pre-cleaned dataset
df = pd.read_csv("cleaned_dataset_final.csv")
df = df[['product_id', 'name', 'brand', 'image_urls', 'source_urls', 'availability', 'merchant', 'min_price', 'currency', 'search']]

# Initialize TF-IDF Vectorizer
tfidf_vectorizer = TfidfVectorizer(stop_words='english')
tfidf_matrix = tfidf_vectorizer.fit_transform(df['search'])

# Creating Flask app
app = Flask(__name__)
app.secret_key = 'your_secret_key'

@app.route('/')
def index():
    username = session.get('username')
    output = None
    return render_template('index.html', output=output, username=username)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username = %s AND pass = %s", (username, password))
        user = cursor.fetchone()
        cursor.close()
        conn.close()

        if user:
            session['username'] = username
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password', 'danger')
            return redirect(url_for('index'))

    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        # Validate input fields
        if not username or not email or not password:
            flash('All fields are required.', 'danger')
            return redirect(url_for('index'))

        # Check if user already exists
        if user_exists(username):
            flash('Username already exists. Please choose another one.', 'danger')
            return redirect(url_for('index'))

        # Save user to database
        save_user(username, email, password)
        flash('Registration successful! You can now log in.', 'success')
        return redirect(url_for('index'))

    return render_template('index')


def user_exists(username):
    conn = get_db_connection()
    cursor = conn.cursor()

    # SQL query to check if the user already exists
    cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
    user = cursor.fetchone()  # Fetch a single record
    cursor.close()
    conn.close()

    return user is not None  # Returns True if user exists


def save_user(username, email, password):
    conn = get_db_connection()
    cursor = conn.cursor()

    # SQL query to insert a new user into the database
    cursor.execute("INSERT INTO users (username, email, pass) VALUES (%s, %s, %s)", (username, email, password))
    conn.commit()  # Commit the transaction
    cursor.close()
    conn.close()

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

@app.route('/recom', methods=['POST'])
def recommend():
    query = request.form['recommend']
    final_df = recommendation(query)

    if 'username' in session:
        user_id = get_user_id(session['username'])
        save_browsing_history(user_id, query)
        save_user_recommendations(user_id, final_df, query)

    if final_df.empty:
        final_df = pd.DataFrame(columns=['name', 'brand', 'image_urls', 'source_urls', 'min_price', 'availability', 'merchant', 'currency'])

    return render_template('index.html', output=final_df)

# Recommendation function using matrix factorization
def recommendation(query):
    query_tfidf = tfidf_vectorizer.transform([query])
    cosine_similarities = cosine_similarity(query_tfidf, tfidf_matrix).flatten()
    df['cosine_similarity'] = cosine_similarities
    similar_products = df.sort_values(by=['cosine_similarity'], ascending=False).head(20)
    similar_product_ids = similar_products['product_id'].values
    user_vector = matrix_factorization[get_user_id(session['username'])]
    predicted_ratings = np.dot(user_vector, svd.components_)
    recommended_indices = predicted_ratings.argsort()[::-1][:20]
    recommended_products = df.iloc[recommended_indices]

    return recommended_products

@app.route('/browsing_history')
def browsing_history():
    if 'username' not in session:
        flash('You need to be logged in to view your browsing history.', 'danger')
        return redirect(url_for('index'))

    user_id = get_user_id(session['username'])
    history_df = get_browsing_history(user_id)

    return render_template('browsing_history.html', history=history_df)

def get_user_id(username):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT user_id FROM users WHERE username = %s", (username,))
    user_id = cursor.fetchone()[0]
    cursor.close()
    conn.close()
    return user_id

def save_browsing_history(user_id, recommend):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO browsing_history (user_id, recommend) VALUES (%s, %s)", (user_id, recommend))
    conn.commit()
    cursor.close()
    conn.close()

def get_browsing_history(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM browsing_history WHERE user_id = %s", (user_id,))
    history = cursor.fetchall()
    cursor.close()
    conn.close()
    return history

@app.route('/delete_selected_history', methods=['POST'])
def delete_selected_history():
    if 'username' not in session:
        flash('You need to be logged in to delete browsing history.', 'danger')
        return redirect(url_for('index'))

    selected_ids = request.form.getlist('history_ids')
    if selected_ids:
        delete_selected_browsing_history(selected_ids)
        delete_corresponding_recommendations(selected_ids)
        flash('Selected browsing history and corresponding recommendations deleted successfully.', 'success')
    else:
        flash('No records selected for deletion.', 'warning')

    return redirect(url_for('browsing_history'))

def delete_selected_browsing_history(history_ids):
    conn = get_db_connection()
    cursor = conn.cursor()
    format_strings = ','.join(['%s'] * len(history_ids))
    cursor.execute(f"DELETE FROM browsing_history WHERE id IN ({format_strings})", tuple(history_ids))
    conn.commit()
    cursor.close()
    conn.close()

def delete_corresponding_recommendations(history_ids):
    user_id = get_user_id(session['username'])
    conn = get_db_connection()
    cursor = conn.cursor()

    # Get product_ids corresponding to the selected history entries
    format_strings = ','.join(['%s'] * len(history_ids))
    cursor.execute(
        f"SELECT DISTINCT product_id FROM user_recommendations WHERE user_id = %s AND recommend IN (SELECT recommend FROM browsing_history WHERE id IN ({format_strings}))",
        (user_id, *history_ids))

    product_ids = cursor.fetchall()

# Delete recommendations for these product IDs
    if product_ids:
        product_ids = [pid[0] for pid in product_ids]
        format_strings = ','.join(['%s'] * len(product_ids))
        cursor.execute(f"DELETE FROM user_recommendations WHERE user_id = %s AND product_id IN ({format_strings})",
                       (user_id, *product_ids))

    conn.commit()
    cursor.close()
    conn.close()

# Function to save user recommendations
def save_user_recommendations(user_id, final_df, query):
    # Get the first 2 product IDs
    first_two_product_ids = final_df['product_id'].head(2).tolist()

    conn = get_db_connection()
    cursor = conn.cursor()
    for product_id in first_two_product_ids:
        cursor.execute("INSERT INTO user_recommendations (user_id, product_id, recommend) VALUES (%s, %s, %s)",
                       (user_id, product_id, query))  # Pass the query instead
    conn.commit()
    cursor.close()
    conn.close()

# Recommendation function
def recommendation(query):
    query_tfidf = tfidf_vectorizer.transform([query])
    cosine_similarities = cosine_similarity(query_tfidf, tfidf_matrix).flatten()

    df['cosine_similarity'] = cosine_similarities
    final_df = df.sort_values(by=['cosine_similarity'], ascending=False).head(20)[
        ['product_id', 'name', 'brand', 'image_urls', 'source_urls', 'availability', 'merchant', 'min_price',
         'currency', 'cosine_similarity']]
    return final_df

@app.route('/user_recommendations')
def user_recommendations():
    if 'username' not in session:
        flash('You need to be logged in to view your recommendations.', 'danger')
        return redirect(url_for('index'))

    user_id = get_user_id(session['username'])

    # Fetch product_ids from user_recommendations table for the logged-in user
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT product_id FROM user_recommendations WHERE user_id = %s", (user_id,))
    product_ids = cursor.fetchall()  # Fetch product_ids as a list of tuples
    cursor.close()
    conn.close()

    if not product_ids:
        flash("You don't have any saved recommendations.", 'warning')
        return render_template('user_recommendations.html', products=None)
    product_ids = [pid[0] for pid in product_ids]
    recommended_products_df = df[df['product_id'].isin(product_ids)]
    recommended_products = recommended_products_df.to_dict('records')

    return render_template('user_recommendations.html', products=recommended_products)

@app.route('/delete_recommendation', methods=['POST'])
def delete_recommendation():
    if 'username' not in session:
        flash('You need to be logged in to delete a recommendation.', 'danger')
        return redirect(url_for('index'))

    product_id = request.form['product_id']
    user_id = get_user_id(session['username'])

    # Delete the recommendation from the database
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM user_recommendations WHERE user_id = %s AND product_id = %s", (user_id, product_id))
    conn.commit()
    cursor.close()
    conn.close()

    flash('Recommendation deleted successfully.', 'success')
    return redirect(url_for('user_recommendations'))

if __name__ == "__main__":
    app.run(debug=True)
